import json
import tkinter as tk
from tkinter import scrolledtext
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def normalize(text):
    clean = "".join([c.lower() if c.isalnum() or c.isspace() else " " for c in text])
    return " ".join([w for w in clean.split() if w])


def load_data(path="data.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def expand_query(query):
    aliases = {
        "ai": "artificial intelligence",
        "ml": "machine learning",
        "nlp": "natural language processing",
    }
    words = query.lower().split()
    expanded = []
    for word in words:
        if word in aliases:
            expanded.append(aliases[word])
        else:
            expanded.append(word)
    return " ".join(expanded)


def get_top_matches(query, data, top_n=3):
    query = expand_query(query)
    questions = [item.get("question", "") for item in data]
    vectorizer = TfidfVectorizer(stop_words="english")
    matrix = vectorizer.fit_transform(questions)
    q_vec = vectorizer.transform([query])
    scores = cosine_similarity(q_vec, matrix)[0]
    ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)[:top_n]
    results = []
    for idx, score in ranked:
        if score <= 0.05:
            continue
        results.append({
            "question": data[idx].get("question", ""),
            "answer": data[idx].get("answer", ""),
            "score": float(score),
        })
    return results


def find_best_answer(query, data):
    if not query.strip():
        return [], "empty"
    results = get_top_matches(query, data, top_n=3)
    if not results:
        return [], "nomatch"
    return results, "match"


def run_accuracy_tests():
    dataset = [
    {"query": "What is Python", "expected": "Python is a programming language."},
    {"query": "Artificial intelligence definition", "expected": "AI is the simulation of human intelligence in machines."},
    {"query": "Machine learning meaning", "expected": "Machine learning is a subset of AI that allows systems to learn from data."},
    {"query": "Natural language processing", "expected": "NLP is about analyzing and understanding text and speech."},
    {"query": "Data science", "expected": "Data science combines statistics, data analysis and machine learning."},

    {"query": "Explain Python language", "expected": "Python is a programming language."},
    {"query": "Define AI", "expected": "AI is the simulation of human intelligence in machines."},
    {"query": "What is ML", "expected": "Machine learning is a subset of AI that allows systems to learn from data."},
    {"query": "NLP meaning", "expected": "NLP is about analyzing and understanding text and speech."},
    {"query": "Explain data science", "expected": "Data science combines statistics, data analysis and machine learning."},

    {"query": "Python uses", "expected": "Python is a programming language."},
    {"query": "AI full form explanation", "expected": "AI is the simulation of human intelligence in machines."},
    {"query": "Machine learning definition", "expected": "Machine learning is a subset of AI that allows systems to learn from data."},
    {"query": "What is NLP used for", "expected": "NLP is about analyzing and understanding text and speech."},
    {"query": "Data science meaning", "expected": "Data science combines statistics, data analysis and machine learning."},

    {"query": "Tell me about Python", "expected": "Python is a programming language."},
    {"query": "What do you mean by artificial intelligence", "expected": "AI is the simulation of human intelligence in machines."},
    {"query": "Explain machine learning", "expected": "Machine learning is a subset of AI that allows systems to learn from data."},
    {"query": "Define natural language processing", "expected": "NLP is about analyzing and understanding text and speech."},
    {"query": "What is data science field", "expected": "Data science combines statistics, data analysis and machine learning."}
]
    data = load_data()
    correct = 0
    for test in dataset:
        results, state = find_best_answer(test["query"], data)
        if state == "match" and results and results[0]["answer"] == test["expected"]:
            correct += 1
    accuracy = correct / len(dataset)
    print(f"Accuracy: {accuracy*100:.1f}% ({correct}/{len(dataset)})")


def build_gui():
    data = load_data()
    root = tk.Tk()
    root.title("Knowledge Base Query Assistant")
    root.geometry("700x500")
    root.resizable(False, False)

    frame = tk.Frame(root, bg="#1b1b2e", padx=20, pady=20)
    frame.pack(fill=tk.BOTH, expand=True)

    title = tk.Label(frame, text="Knowledge Base Query Assistant", font=("Segoe UI", 22, "bold"), fg="#f7f7fc", bg="#1b1b2e")
    title.pack(pady=(0, 15))

    query_frame = tk.Frame(frame, bg="#1b1b2e")
    query_frame.pack(fill=tk.X, pady=(0, 10))

    query_label = tk.Label(query_frame, text="Enter your query:", font=("Segoe UI", 15), fg="#d6d6e0", bg="#1b1b2e")
    query_label.pack(side=tk.LEFT)

    query_text = tk.Entry(query_frame, font=("Segoe UI", 15), width=52, bg="#2a2a44", fg="#f4f4ff", insertbackground="#ffffff")
    query_text.pack(side=tk.LEFT, padx=(10, 0))
    query_text.focus()

    status_var = tk.StringVar()
    status_var.set("Ready")

    def do_search(event=None):
        user_query = query_text.get().strip()
        if not user_query:
            status_var.set("Input required")
            output_area.delete("1.0", tk.END)
            output_area.insert(tk.END, "Please enter a query before searching.")
            return
        status_var.set("Searching...")
        root.update_idletasks()
        print("User query:", user_query)
        results, state = find_best_answer(user_query, data)
        output_area.delete("1.0", tk.END)
        if state == "nomatch":
            output_area.insert(tk.END, "No relevant answer found")
            print("No relevant answers")
        else:
            for i, item in enumerate(results, 1):
                output_area.insert(tk.END, f"{i}. Q: {item['question']}\n")
                output_area.insert(tk.END, f"Answer: {item['answer']}\n")
                output_area.insert(tk.END, f"Similarity: {item['score']:.4f}\n\n")
                print(f"Matched: {item['question']} -> {item['score']:.4f}")
        status_var.set("Done")
        query_text.delete(0, tk.END)

    button_frame = tk.Frame(frame, bg="#1b1b2e")
    button_frame.pack(fill=tk.X, pady=(0, 10))

    search_btn = tk.Button(button_frame, text="Search", font=("Segoe UI", 14), width=10, bg="#4978d4", fg="#ffffff", activebackground="#6198ff", command=do_search)
    search_btn.pack(side=tk.LEFT, padx=(0, 10))

    clear_btn = tk.Button(button_frame, text="Clear", font=("Segoe UI", 14), width=10, bg="#6b6bc3", fg="#ffffff", activebackground="#8484e6", command=lambda: [query_text.delete(0, tk.END), output_area.delete("1.0", tk.END), status_var.set("Ready")])
    clear_btn.pack(side=tk.LEFT, padx=(0, 10))

    status_label = tk.Label(button_frame, textvariable=status_var, font=("Segoe UI", 12), fg="#d6d6e0", bg="#1b1b2e")
    status_label.pack(side=tk.LEFT, padx=(10, 0))

    output_frame = tk.Frame(frame, bg="#1b1b2e")
    output_frame.pack(fill=tk.BOTH, expand=True)

    output_area = scrolledtext.ScrolledText(output_frame, wrap=tk.WORD, font=("Segoe UI", 14), bg="#262640", fg="#eff0ff", insertbackground="#ffffff")
    output_area.pack(fill=tk.BOTH, expand=True)

    exit_btn = tk.Button(frame, text="Exit", font=("Segoe UI", 14), width=10, bg="#d44f5b", fg="#ffffff", activebackground="#ec6a75", command=root.destroy)
    exit_btn.pack(pady=(10, 0))

    root.bind("<Return>", do_search)
    root.mainloop()


if __name__ == "__main__":
    run_accuracy_tests()
    build_gui()