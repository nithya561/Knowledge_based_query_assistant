from kbqa_gui import load_data, find_best_answer

data = load_data()
tests = [
    {'query':'What is Python','expected':'Python is a programming language.'},
    {'query':'Artificial intelligence definition','expected':'AI is the simulation of human intelligence in machines.'},
    {'query':'Machine learning meaning','expected':'Machine learning is a subset of AI that allows systems to learn from data.'},
    {'query':'NLP','expected':'NLP is about analyzing and understanding text and speech.'},
    {'query':'Data science','expected':'Data science combines statistics, data analysis and machine learning.'}
]
for t in tests:
    ans, state = find_best_answer(t['query'], data)
    print(t['query'], '->', ans, state, 'expected', t['expected'])
