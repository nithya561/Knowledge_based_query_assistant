import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class KnowledgeBase:
    def __init__(self, docs=None):
        self.docs = docs or []
        self.vectorizer = TfidfVectorizer()
        self.matrix = None

    @classmethod
    def from_json(cls, path):
        with open(path, "r", encoding="utf-8") as f:
            docs = json.load(f)
        return cls(docs)

    def fit(self):
        corpus = [f"{doc.get('title','')} {doc.get('content','')}" for doc in self.docs]
        self.matrix = self.vectorizer.fit_transform(corpus)

    def query(self, text, top_n=3):
        if self.matrix is None:
            self.fit()
        q_vec = self.vectorizer.transform([text])
        scores = cosine_similarity(q_vec, self.matrix)[0]
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)[:top_n]
        return [
            {
                "id": self.docs[i].get("id"),
                "title": self.docs[i].get("title"),
                "content": self.docs[i].get("content"),
                "score": float(score),
            }
            for i, score in ranked
        ]