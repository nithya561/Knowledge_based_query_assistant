from .query import query_kb

class TopKAccuracy:
    def __init__(self, k=3):
        self.k = k

    def score(self, dataset):
        hits = 0
        total = len(dataset)
        for record in dataset:
            results = query_kb(record["source"], record["query"], self.k)
            top_ids = [r["id"] for r in results]
            if record["expected_id"] in top_ids:
                hits += 1
        return hits / total if total else 0.0