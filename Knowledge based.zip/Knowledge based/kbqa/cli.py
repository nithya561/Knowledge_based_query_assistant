import argparse
from .core import KnowledgeBase

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data.json")
    parser.add_argument("--query", required=True)
    parser.add_argument("--top", type=int, default=3)
    args = parser.parse_args()
    kb = KnowledgeBase.from_json(args.data)
    results = kb.query(args.query, args.top)
    for i, item in enumerate(results, 1):
        print(i, item["title"], f"{item['score']:.4f}")

if __name__ == "__main__":
    main()