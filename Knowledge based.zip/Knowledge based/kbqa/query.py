from .core import KnowledgeBase

def query_kb(path, text, top_n=3):
    kb = KnowledgeBase.from_json(path)
    return kb.query(text, top_n)
