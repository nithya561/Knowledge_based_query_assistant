import os
from kbqa.core import KnowledgeBase
from kbqa.query import query_kb
from kbqa.evaluate import TopKAccuracy

def test_query_returns_top3():
    path = os.path.join(os.path.dirname(__file__), "..", "data.json")
    results = query_kb(path, "what is machine learning", top_n=3)
    assert len(results) == 3

def test_similarity_scores_descending():
    path = os.path.join(os.path.dirname(__file__), "..", "data.json")
    kb = KnowledgeBase.from_json(path)
    results = kb.query("artificial intelligence and language", top_n=3)
    assert results[0]["score"] >= results[1]["score"] >= results[2]["score"]

def test_topk_accuracy_score():
    path = os.path.join(os.path.dirname(__file__), "..", "data.json")
    dataset = [
        {"source": path, "query": "what is python", "expected_id": "1"},
        {"source": path, "query": "ai language processing", "expected_id": "4"},
        {"source": path, "query": "data insights analytics", "expected_id": "5"},
    ]
    metric = TopKAccuracy(k=3)
    score = metric.score(dataset)
    assert score == 1.0